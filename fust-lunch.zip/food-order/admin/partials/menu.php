<?php 

    include('../config/constants.php'); 
    include('login-check.php');

?>


<html>
    <head>
        <title>Fast_lunch(for admin)</title>

        <link rel="stylesheet" href="../css/admin.css">
    </head>
    
    <body>
        <!-- Верхняя менюшка -->
        <div class="menu text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">Вся информация</a></li>
                    <li><a href="manage-admin.php">Администратор</a></li>
                    <li><a href="manage-category.php">Категории</a></li>
                    <li><a href="manage-food.php">Еда</a></li>
                    <li><a href="manage-order.php">Заказы</a></li>
                    <li><a href="logout.php">Выйти</a></li>
                </ul>
            </div>
        </div>
       